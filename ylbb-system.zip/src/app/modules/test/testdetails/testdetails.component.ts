import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testdetails',
  templateUrl: './testdetails.component.html',
  styleUrls: ['./testdetails.component.scss']
})
export class TestdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
